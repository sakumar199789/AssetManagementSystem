package com.capgemini.asset.pi;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.asset.bean.AssetBean;
import com.capgemini.asset.bean.AssetRequestBean;
import com.capgemini.asset.bean.AssetRequestFormBean;
import com.capgemini.asset.bean.EmployeeBean;
import com.capgemini.asset.exception.AssetException;
import com.capgemini.asset.service.AssetImpl;
import com.capgemini.asset.service.IAssetInterface;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/**
 * Servlet implementation class AssetController
 */
@WebServlet("/AssetController")
public class AssetController extends HttpServlet {
	IAssetInterface ie=new AssetImpl();
	HttpSession session=null;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssetController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 session=request.getSession(false);
		ArrayList<AssetBean> al=new ArrayList();
		ArrayList<EmployeeBean> employee=new ArrayList();
		
		switch(request.getParameter("action")) {
			case "RaiseRequest":
					if(session!=null) {
					try{
					al=ie.viewAssets();
					
					employee=ie.getEmployeeDetails((int)session.getAttribute("mgr"));
					}
					catch(Exception e){
						System.out.println(e);
					}
					request.setAttribute("assetlist",al);
					session.setAttribute("employeeId", employee);
					request.getRequestDispatcher("/RaiseRequest.jsp").forward(request, response);
					}
					else
					{
						request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
					}
					break;
				
			case "export":
				if(session!=null) {
				try{
					ArrayList<AssetBean> assetlist=ie.getAssetDetails();
					  
						HSSFWorkbook workBook = new HSSFWorkbook();
			            HSSFSheet sheet = workBook.createSheet();
			            HSSFRow headingRow = sheet.createRow(0);
			            headingRow.createCell((short)0).setCellValue("Asset Id");
			            headingRow.createCell((short)1).setCellValue("Asset Name");
			            headingRow.createCell((short)2).setCellValue("Asset Description");
			            headingRow.createCell((short)3).setCellValue("Quantity");
			            headingRow.createCell((short)4).setCellValue("Status");
			            short rowNo = 1;
			            for (AssetBean asset : assetlist) {
			                HSSFRow row = sheet.createRow(rowNo);
			                row.createCell((short)0).setCellValue(asset.getAssetId());
			                row.createCell((short)1).setCellValue(asset.getAssetName());
			                row.createCell((short)2).setCellValue(asset.getAssetDes());
			                row.createCell((short)3).setCellValue(asset.getQuantity());
			                row.createCell((short)4).setCellValue(asset.getStatus());
			                rowNo++;
			            }
			             
			            String file = "D:/Assetdetails.xls";
			            try{
			                FileOutputStream fos = new FileOutputStream(file);
			                workBook.write(fos);
			                fos.flush();
			            }catch(FileNotFoundException e){
			                e.printStackTrace();
			                System.out.println("Invalid directory or file not found");
			            }catch(IOException e){
			                e.printStackTrace();
			                System.out.println("Error occurred while writting excel file to directory");
			            }
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
				
			case "modify":
				if(session!=null) {
					//System.out.println(ss.getId());
				try {
					ArrayList<AssetBean> assets=ie.getAssetDetails();
					session.setAttribute("assetlist", assets);
					request.getRequestDispatcher("/DisplayAssetsAdmin.jsp").forward(request, response);
					}
					catch(Exception e)
					{
					System.out.println(e);
					}
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
				
				
			case "edit":
				if(session!=null) {
				request.setAttribute("id", request.getParameter("id"));
				request.setAttribute("name", request.getParameter("name"));
				request.setAttribute("des", request.getParameter("des"));
				request.setAttribute("quantity", request.getParameter("quantity"));
				request.setAttribute("status", request.getParameter("status"));
				
				request.getRequestDispatcher("/ModifyAsset.jsp").include(request, response);
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
				
			case "viewrequest":
				if(session!=null) 
				request.getRequestDispatcher("/viewrequest1.jsp").include(request, response);
				else
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				break;
				
			case "AssetAlloc":
				if(session!=null) {
				try{
					AssetRequestBean assetRequest=new AssetRequestBean();
					assetRequest.setRequestId(Integer.parseInt(request.getParameter("requestid")));
					assetRequest.setAssetId(Integer.parseInt(request.getParameter("assetid")));
					assetRequest.setEmpid(Integer.parseInt(request.getParameter("empid")));
					assetRequest.setAssetName(request.getParameter("assetname"));
					assetRequest.setAssetDes(request.getParameter("assetdes"));
					assetRequest.setQuantity(Integer.parseInt(request.getParameter("quantity")));
					
					if(ie.isValidQuantity(assetRequest)){
						if(request.getParameter("operation").equals("Accept")){
							System.out.println(ie.modifyStatus("Accept",assetRequest)+"for Request Id:"+assetRequest.getRequestId());
						}
						
					}
					else
					{
						System.out.println("Asset is Not Available");
						//ie.modifyStatus("Reject",ar);
					}
					if(request.getParameter("operation").equals("Reject"))
					{
						System.out.println(ie.modifyStatus("Reject",assetRequest)+"for Request Id:"+assetRequest.getRequestId());
					}
					
					}
					catch(SQLException a){
						System.out.println("DBconnection Problem");
						
					}
					catch(Exception e){
						System.out.println(e);
					}
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
				
			case "GenerateReport":
				if(session!=null) {
				try{
					if(request.getParameter("operation").equals("allocatedassets")){
						ArrayList<AssetBean> assets=ie.allocatedDetails();
						request.setAttribute("allocated", assets);
						request.getRequestDispatcher("/Reports.jsp").forward(request, response);
						}
						else
						{
							ArrayList<AssetBean> assets=ie.nonAllocatedDetails();
							request.setAttribute("allocated", assets);
							request.getRequestDispatcher("/Reports.jsp").forward(request, response);
						}
					}
					catch(Exception e){
							System.out.println(e);
					}
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
				
			case "viewrequeststatus":
				if(session!=null)
				request.getRequestDispatcher("viewrequeststatus1.jsp").forward(request, response);
				else
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				break;
				
			case "ViewStatus":
				if(session!=null) {
				ArrayList<AssetRequestBean> requestStatus=new ArrayList();
				try{
					//System.out.println("hai in status");
					requestStatus=ie.viewRequestDetails(Integer.parseInt(request.getParameter("requestId")));		
					request.setAttribute("requestStatus", requestStatus);
					request.getRequestDispatcher("viewrequeststatus2.jsp").forward(request, response);
				}
				catch(Exception e) {
			
				}
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
			case "addnewasset":
				if(session!=null) 
					request.getRequestDispatcher("AddNewAsset.jsp").forward(request, response);
				else
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				break;
				
			case "logout":
				HttpSession session=request.getSession(false);
				//System.out.println(session.isNew()+" "+session.getId());
				if(session==null){
						
				}
				else{
					System.out.println("Logout");
			session.invalidate();
				request.getRequestDispatcher("/Logout.jsp").include(request, response);
				
					}
				break;
				
	}
}	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AssetBean asset;
		
		switch(request.getParameter("action")) {
		case "login":
			session=request.getSession(true);
			System.out.println(session.isNew()+" "+session.getId());
			session.setAttribute("uname", request.getParameter("UserName"));
			session.setAttribute("pass", request.getParameter("password"));
			request.getRequestDispatcher("/LoginServlet").forward(request,response);
			break;
			
		case "addnewasset":
			if(session!=null) {
			asset=new AssetBean();
			System.out.println("Insert");
			asset.setAssetId(Long.parseLong(request.getParameter("assetid")));
			asset.setAssetName(request.getParameter("assetname"));
			asset.setAssetDes(request.getParameter("assetdes"));
			asset.setQuantity(Integer.parseInt(request.getParameter("quantity")));
			asset.setStatus( request.getParameter("status"));
			
			try{
				ie.addNewAsset(asset);
				session.setAttribute("assetId", request.getParameter("assetid"));
				request.getRequestDispatcher("AddNewAssetmsg.jsp").include(request, response);
				}
				catch(AssetException a){
					System.out.println(a);
				}
				catch(SQLException s1){
					System.out.println(s1.getMessage());
				}
			}
			else
			{
				request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
			}
			break;
			
			
		case "save":
			if(session!=null) { 
			asset=new AssetBean();
			System.out.println("Modify");
			asset.setAssetId(Long.parseLong(request.getParameter("assetid")));
			asset.setAssetName(request.getParameter("assetname"));
			asset.setAssetDes(request.getParameter("assetdes"));
			asset.setQuantity(Integer.parseInt(request.getParameter("quantity")));
			asset.setStatus( request.getParameter("status"));
			
			try{
				ie.modifyAssetDetails(asset);
				}
				catch(AssetException a){
					System.out.println(a);
				}
				catch(SQLException s1){
					System.out.println(s1.getMessage());
				}
			}
			else
			{
				request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
			}
			break;
		
		case "Find":
			if(session!=null) {
			ArrayList<AssetRequestBean> assetRequest=new ArrayList();
			try{
				assetRequest=ie.viewAssetRequestDetails(Integer.parseInt(request.getParameter("assetid")));
			}
			catch(Exception e){
				System.out.println(e);
			}
			if(assetRequest.size()==0){
				System.out.println("No Requests available for entered asset id: "+request.getParameter("assetid"));
			}
			else
			{
				request.setAttribute("assetRequest", assetRequest);
				request.getRequestDispatcher("/viewrequest2.jsp").forward(request, response);
			}
			}
			else
			{
				request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				
			}
			break;
		
		case "RaiseRequest":
			if(session!=null) { 
				AssetRequestFormBean raiseRequest=new AssetRequestFormBean();
			
				raiseRequest.setEmpId(Integer.parseInt(request.getParameter("empid")));
				raiseRequest.setEmpName(request.getParameter("empName"));
				raiseRequest.setDeptId(Integer.parseInt(request.getParameter("deptid")));
				raiseRequest.setAssetName(request.getParameter("assetname"));
				raiseRequest.setAssetPurpose(request.getParameter("assetpurpose"));
				raiseRequest.setQuan(Integer.parseInt(request.getParameter("quantity")));
			
				
				try{
					int requestId=ie.raiseRequest(raiseRequest);
					session.setAttribute("requestId", requestId);
					request.getRequestDispatcher("RaiseRequestMsg.jsp").include(request, response);
					}
					catch(AssetException a){
						System.out.println(a);
					}
					catch(SQLException s1){
						System.out.println(s1.getMessage());
					}
				}
				else
				{
					request.getRequestDispatcher("sessionerrorpage.jsp").forward(request, response);
				}
				break;
			
		}
}
		
	
}
